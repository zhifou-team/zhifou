function getPersonalInfo() {
    
}

function displayInfo(type) {

    if(type === "dynamic"){

    }

}